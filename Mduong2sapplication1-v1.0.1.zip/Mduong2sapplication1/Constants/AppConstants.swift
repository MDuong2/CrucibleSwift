//
//  AppConstants.swift
//  Mduong2sapplication1

import Foundation

struct AppConstants {
    static let serverURL: String = "@{serverURL}"
}
