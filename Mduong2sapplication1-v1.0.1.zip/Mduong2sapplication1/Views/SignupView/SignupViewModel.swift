import Foundation
import SwiftUI

class SignupViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
