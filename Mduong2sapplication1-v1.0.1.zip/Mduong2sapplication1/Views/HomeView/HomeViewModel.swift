import Foundation
import SwiftUI

class HomeViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
