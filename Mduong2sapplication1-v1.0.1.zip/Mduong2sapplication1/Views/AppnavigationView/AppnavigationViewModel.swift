import Foundation
import SwiftUI

class AppnavigationViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
