import Foundation
import SwiftUI

class NutritionViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
