import Foundation
import SwiftUI

class NotificationViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
